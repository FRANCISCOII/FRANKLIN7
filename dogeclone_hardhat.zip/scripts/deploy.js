async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const Doge = await ethers.getContractFactory("DogeClone");
  const doge = await Doge.deploy();
  await doge.deployed();

  console.log("DogeClone deployed to:", doge.address);
}

main().catch((e) => { console.error(e); process.exit(1); });
